
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { PatientData, Tab, Status } from './types';
import Home from './screens/Home';
import Requirements from './screens/Requirements';
import Appointments from './screens/Appointments';
import Documents from './screens/Documents';

const INITIAL_PATIENT_DATA: PatientData = {
  name: "Sarah",
  surgeryType: "Gastric Bypass",
  coordinator: { name: "Amanda Smith" },
  insurance: { 
    provider: "BlueCross PPO", 
    procedureCode: "43644", 
    coverage: "Covered w/ Conditions", 
    authRequired: true 
  },
  requirements: [
    { id: "bmi", title: "BMI Requirement", status: "complete", detail: "BMI ≥ 40 OR ≥ 35 with qualifying conditions", meta: { bmi: 42.3, verifiedDate: "2026-02-01" } },
    { id: "supervised", title: "Supervised Weight Management", status: "in_progress", detail: "6 documented monthly visits required", meta: { 
      completed: 4, 
      total: 6, 
      visits: [
        { label: "Visit 1", date: "2026-01-03", done: true },
        { label: "Visit 2", date: "2026-02-01", done: true },
        { label: "Visit 3", date: "2026-03-02", done: true },
        { label: "Visit 4", date: "2026-04-01", done: true },
        { label: "Visit 5", date: null, done: false },
        { label: "Visit 6", date: null, done: false }
      ] 
    } },
    { id: "psych", title: "Psychological Evaluation", status: "not_started", detail: "Formal behavioral health clearance required", meta: {} },
    { id: "labs", title: "Pre-Operative Lab Panel", status: "complete", detail: "CBC, CMP, A1C", meta: { completedDate: "2026-02-01" } },
    { id: "pcp", title: "Primary Care Clearance", status: "in_progress", detail: "Formal letter of surgical clearance", meta: { submittedDate: "2026-02-05" } }
  ],
  appointments: {
    upcoming: [
      { id: "appt1", title: "Nutrition Visit #3", date: "2026-02-12", time: "10:00 AM", location: "In Office – Augusta Clinic" },
      { id: "appt2", title: "Psychological Evaluation", date: null, time: null, location: "Telehealth", needsScheduling: true }
    ],
    completed: [
      { id: "c1", title: "Nutrition Visit #1", date: "2026-01-03" },
      { id: "c2", title: "Initial Consultation", date: "2025-12-15" }
    ]
  },
  documents: [
    { id: "doc_ins", name: "Insurance Card", status: "verified", uploadedDate: "2026-02-02", type: "image" },
    { id: "doc_pcp", name: "Primary Care Clearance", status: "under_review", uploadedDate: "2026-02-05", type: "pdf" },
    { id: "doc_psych", name: "Psychological Evaluation", status: "not_submitted", uploadedDate: null, type: "pdf" },
    { id: "doc_weight", name: "Weight Logs", status: "approved", uploadedDate: "2026-01-28", type: "pdf" }
  ]
};

const Toast: React.FC<{ message: string; onHide: () => void }> = ({ message, onHide }) => {
  useEffect(() => {
    const t = setTimeout(onHide, 3000);
    return () => clearTimeout(t);
  }, [onHide]);

  return (
    <div className="fixed top-12 left-1/2 -translate-x-1/2 z-50 bg-app-text-dark text-white px-6 py-3 rounded-full text-sm font-medium shadow-lg whitespace-nowrap animate-bounce">
      {message}
    </div>
  );
};

const BottomNav: React.FC<{ activeTab: Tab; onTabChange: (tab: Tab) => void }> = ({ activeTab, onTabChange }) => {
  const tabs = [
    { id: Tab.Home, icon: 'home', label: 'Home' },
    { id: Tab.Requirements, icon: 'assignment_turned_in', label: 'Requirements' },
    { id: Tab.Appointments, icon: 'calendar_today', label: 'Appointments' },
    { id: Tab.Documents, icon: 'description', label: 'Documents' },
  ];

  return (
    <nav className="absolute bottom-0 left-0 right-0 bg-white/80 backdrop-blur-md border-t border-slate-100 px-6 pt-3 pb-8 flex justify-between items-center z-40">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onTabChange(tab.id)}
          className={`flex flex-col items-center gap-1 transition-all ${
            activeTab === tab.id ? 'text-app-primary' : 'text-slate-400'
          }`}
        >
          <span className={`material-symbols-outlined ${activeTab === tab.id ? 'fill-[1]' : ''}`}>
            {tab.icon}
          </span>
          <span className="text-[10px] font-bold uppercase tracking-tighter">
            {tab.label}
          </span>
        </button>
      ))}
      <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-32 h-1.5 bg-gray-200 rounded-full"></div>
    </nav>
  );
};

export default function App() {
  const [patient, setPatient] = useState<PatientData>(INITIAL_PATIENT_DATA);
  const [activeTab, setActiveTab] = useState<Tab>(Tab.Home);
  const [toast, setToast] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => setToast(msg), []);

  const handleScheduleAppointment = (id: string) => {
    setPatient(prev => {
      const updatedUpcoming = prev.appointments.upcoming.map(appt => {
        if (appt.id === id) {
          return { ...appt, date: '2026-03-15', time: '02:00 PM', needsScheduling: false };
        }
        return appt;
      });
      return { ...prev, appointments: { ...prev.appointments, upcoming: updatedUpcoming } };
    });
    showToast("Appointment Scheduled!");
  };

  const handleUploadDocument = (id: string) => {
    setPatient(prev => {
      const updatedDocs = prev.documents.map(doc => {
        if (doc.id === id) {
          return { ...doc, status: 'under_review' as Status, uploadedDate: new Date().toISOString().split('T')[0] };
        }
        return doc;
      });
      return { ...prev, documents: updatedDocs };
    });
    showToast("Document Uploaded!");
  };

  const nextStep = useMemo(() => {
    const unscheduledAppt = patient.appointments.upcoming.find(a => a.needsScheduling);
    if (unscheduledAppt) return { type: 'appointment', item: unscheduledAppt };

    const unsubmittedDoc = patient.documents.find(d => d.status === 'not_submitted');
    if (unsubmittedDoc) return { type: 'document', item: unsubmittedDoc };

    const nextRequirement = patient.requirements.find(r => r.status !== 'complete');
    return { type: 'requirement', item: nextRequirement };
  }, [patient]);

  const renderScreen = () => {
    switch (activeTab) {
      case Tab.Home:
        return <Home patient={patient} onTabChange={setActiveTab} showToast={showToast} nextStep={nextStep} />;
      case Tab.Requirements:
        return <Requirements patient={patient} />;
      case Tab.Appointments:
        return <Appointments patient={patient} onSchedule={handleScheduleAppointment} showToast={showToast} />;
      case Tab.Documents:
        return <Documents patient={patient} onUpload={handleUploadDocument} />;
      default:
        return <Home patient={patient} onTabChange={setActiveTab} showToast={showToast} nextStep={nextStep} />;
    }
  };

  return (
    <div className="relative h-full w-full flex flex-col font-sans text-app-text-dark bg-app-bg overflow-hidden">
      {toast && <Toast message={toast} onHide={() => setToast(null)} />}
      <div className="flex-1 overflow-y-auto no-scrollbar pb-24">
        {renderScreen()}
      </div>
      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}
