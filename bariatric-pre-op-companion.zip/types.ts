
export type Status = 'complete' | 'in_progress' | 'not_started' | 'pending' | 'under_review' | 'verified' | 'approved' | 'not_submitted' | 'missing';

export interface Requirement {
  id: string;
  title: string;
  status: Status;
  detail: string;
  meta: {
    bmi?: number;
    verifiedDate?: string;
    completed?: number;
    total?: number;
    completedDate?: string;
    submittedDate?: string;
    visits?: Array<{ label: string; date: string | null; done: boolean }>;
  };
}

export interface Appointment {
  id: string;
  title: string;
  date: string | null;
  time: string | null;
  location: string;
  needsScheduling?: boolean;
}

export interface CompletedAppointment {
  id: string;
  title: string;
  date: string;
}

export interface Document {
  id: string;
  name: string;
  status: Status;
  uploadedDate: string | null;
  type: 'image' | 'pdf';
}

export interface PatientData {
  name: string;
  surgeryType: string;
  coordinator: { name: string };
  insurance: {
    provider: string;
    procedureCode: string;
    coverage: string;
    authRequired: boolean;
  };
  requirements: Requirement[];
  appointments: {
    upcoming: Appointment[];
    completed: CompletedAppointment[];
  };
  documents: Document[];
}

export enum Tab {
  Home = 'Home',
  Requirements = 'Requirements',
  Appointments = 'Appointments',
  Documents = 'Documents'
}
