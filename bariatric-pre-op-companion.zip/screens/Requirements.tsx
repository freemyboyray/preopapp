
import React, { useState } from 'react';
import { PatientData } from '../types';

export default function Requirements({ patient }: { patient: PatientData }) {
  const [expandedId, setExpandedId] = useState<string | null>('supervised');

  return (
    <div className="px-5 py-6 space-y-6">
      <header className="text-center mb-8">
        <h1 className="text-xl font-bold tracking-tight">Surgery Requirements</h1>
        <p className="text-[10px] font-bold text-app-text-muted uppercase tracking-widest mt-1">
          Insurance & Medical Clearance Criteria
        </p>
      </header>

      {/* Insurance Overview Card */}
      <section className="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
        <div className="grid grid-cols-2 gap-y-6">
          <div className="space-y-1">
            <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Provider</p>
            <p className="text-sm font-bold text-app-text-dark">{patient.insurance.provider}</p>
          </div>
          <div className="space-y-1 pl-4 border-l border-slate-100">
            <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Procedure Code</p>
            <p className="text-sm font-bold text-app-text-dark">{patient.insurance.procedureCode}</p>
          </div>
          <div className="space-y-1">
            <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Coverage</p>
            <p className="text-sm font-bold text-app-text-dark">{patient.insurance.coverage}</p>
          </div>
          <div className="space-y-1 pl-4 border-l border-slate-100">
            <p className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Auth Required</p>
            <p className="text-sm font-bold text-app-text-dark">{patient.insurance.authRequired ? 'Yes' : 'No'}</p>
          </div>
        </div>
      </section>

      {/* Medical Necessity Modules */}
      <section className="space-y-4">
        <h2 className="text-[11px] font-bold uppercase tracking-widest text-app-text-muted ml-1">
          Medical Necessity Modules
        </h2>
        {patient.requirements.map(req => (
          <div 
            key={req.id} 
            className="bg-white rounded-xl overflow-hidden flex shadow-sm border border-slate-100 cursor-pointer"
            onClick={() => setExpandedId(expandedId === req.id ? null : req.id)}
          >
            <div className={`w-1.5 ${req.status === 'complete' ? 'bg-app-primary/40' : req.status === 'in_progress' ? 'bg-app-accent' : 'bg-slate-200'}`}></div>
            <div className="p-4 flex-1">
              <div className="flex justify-between items-start mb-1">
                <h3 className="font-bold text-sm">{req.title}</h3>
                <span className={`text-[9px] font-bold px-2 py-0.5 rounded uppercase tracking-wider ${
                  req.status === 'complete' ? 'bg-blue-50 text-app-primary' : 
                  req.status === 'in_progress' ? 'bg-orange-50 text-app-accent' : 
                  'bg-slate-100 text-slate-400'
                }`}>
                  {req.status.replace('_', ' ')}
                </span>
              </div>
              
              {expandedId === req.id ? (
                <div className="mt-3 space-y-3 animate-in fade-in slide-in-from-top-2 duration-300">
                  <p className="text-xs text-app-text-muted italic">{req.detail}</p>
                  {req.meta.visits && (
                    <div className="grid grid-cols-2 gap-4 pt-2 border-t border-slate-50">
                      <div>
                        <p className="text-[9px] font-bold text-slate-400 uppercase">Completed</p>
                        <p className="text-xs font-bold">{req.meta.completed} of {req.meta.total} visits</p>
                      </div>
                      <div>
                        <p className="text-[9px] font-bold text-slate-400 uppercase">Remaining</p>
                        <p className="text-xs font-bold">{(req.meta.total || 0) - (req.meta.completed || 0)} visits</p>
                      </div>
                    </div>
                  )}
                  {req.meta.completedDate && (
                    <div className="pt-2 border-t border-slate-50">
                       <p className="text-[9px] font-bold text-slate-400 uppercase">Service Date</p>
                       <p className="text-xs font-bold">{req.meta.completedDate}</p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="mt-1">
                  {req.status === 'complete' && <p className="text-[10px] text-slate-400">Verified {req.meta.completedDate || req.meta.verifiedDate}</p>}
                  {req.status === 'in_progress' && <p className="text-[10px] text-slate-400">{req.meta.completed}/{req.meta.total} milestones done</p>}
                </div>
              )}
            </div>
          </div>
        ))}
      </section>

      {/* Doc Tracking Summary */}
      <section className="bg-white rounded-2xl overflow-hidden shadow-sm border border-slate-100">
        <div className="px-5 py-4 border-b border-slate-50">
          <h2 className="text-[11px] font-bold uppercase tracking-widest text-app-text-muted">Documentation Tracking</h2>
        </div>
        <div className="divide-y divide-slate-50">
          {patient.documents.map(doc => (
            <div key={doc.id} className="px-5 py-3 flex items-center justify-between">
              <span className={`text-sm font-medium ${doc.status === 'not_submitted' ? 'text-slate-400' : 'text-app-text-dark'}`}>{doc.name}</span>
              <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full border ${
                doc.status === 'verified' || doc.status === 'approved' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' :
                doc.status === 'under_review' ? 'bg-amber-50 text-amber-600 border-amber-100' :
                'bg-slate-50 text-slate-400 border-slate-100'
              }`}>
                {doc.status.toUpperCase().replace('_', ' ')}
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* Readiness Summary */}
      <section className="bg-slate-100/50 rounded-2xl p-5 border border-slate-200">
        <div className="flex gap-3">
          <span className="material-symbols-outlined text-app-accent text-xl">info</span>
          <div className="space-y-2">
            <p className="text-sm font-bold leading-tight">You are currently missing 2 required items to finalize your clearance:</p>
            <ul className="text-xs text-app-text-muted space-y-1 list-disc list-inside">
              <li>Psychological Evaluation completion</li>
              <li>Final 2 Weight Management visits</li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
}
