
import React, { useState } from 'react';
import { PatientData, Appointment } from '../types';

interface AppointmentsProps {
  patient: PatientData;
  onSchedule: (id: string) => void;
  showToast: (msg: string) => void;
}

export default function Appointments({ patient, onSchedule, showToast }: AppointmentsProps) {
  const [completedExpanded, setCompletedExpanded] = useState(true);

  return (
    <div className="px-5 py-8">
      <header className="text-center mb-8">
        <h1 className="font-serif text-3xl font-bold tracking-tight">Appointments</h1>
        <p className="text-[10px] font-bold text-app-text-muted uppercase tracking-widest mt-1">
          Upcoming & Completed Visits
        </p>
      </header>

      {/* Upcoming Section */}
      <section className="mb-10">
        <h2 className="text-[11px] font-bold text-app-text-muted mb-4 uppercase tracking-widest px-1">Upcoming</h2>
        <div className="space-y-4">
          {patient.appointments.upcoming.filter(a => !a.needsScheduling).map(appt => (
            <div key={appt.id} className="bg-white rounded-2xl shadow-sm border-l-4 border-app-primary overflow-hidden border-y border-r border-slate-100">
              <div className="p-5">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h3 className="text-lg font-bold text-app-text-dark mb-1">{appt.title}</h3>
                    <div className="flex items-center gap-2 text-app-text-muted text-sm mb-1">
                      <span className="material-symbols-outlined text-[18px]">calendar_today</span>
                      <span>{appt.date} • {appt.time}</span>
                    </div>
                    <div className="flex items-center gap-2 text-app-text-muted text-sm">
                      <span className="material-symbols-outlined text-[18px]">location_on</span>
                      <span>{appt.location}</span>
                    </div>
                  </div>
                  <span className="material-symbols-outlined text-slate-200">chevron_right</span>
                </div>
                <div className="flex gap-3 pt-4 border-t border-slate-50">
                  <button onClick={() => showToast("Request sent to clinic")} className="flex-1 h-10 rounded-lg border border-slate-200 text-app-text-dark text-[13px] font-bold hover:bg-slate-50">
                    Reschedule
                  </button>
                  <button onClick={() => showToast("Added to calendar")} className="flex-1 h-10 rounded-lg border border-slate-200 text-app-text-dark text-[13px] font-bold hover:bg-slate-50 flex items-center justify-center gap-2">
                    <span className="material-symbols-outlined text-[16px]">event</span>
                    Add to Calendar
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Action Required Section */}
      <section className="mb-10">
        <h2 className="text-[11px] font-bold text-app-text-muted mb-4 uppercase tracking-widest px-1">Action Required</h2>
        {patient.appointments.upcoming.filter(a => a.needsScheduling).map(appt => (
          <div key={appt.id} className="bg-white rounded-2xl shadow-sm border-l-4 border-app-accent p-5 border-y border-r border-slate-100">
            <div className="mb-4">
              <h3 className="text-lg font-bold text-app-text-dark">{appt.title}</h3>
              <div className="flex items-center gap-1.5 mt-1">
                <span className="w-2 h-2 rounded-full bg-app-accent"></span>
                <span className="text-app-accent text-[10px] font-bold uppercase tracking-wider">Not Scheduled</span>
              </div>
            </div>
            <button 
              onClick={() => onSchedule(appt.id)}
              className="w-full h-12 bg-app-primary text-white rounded-xl font-bold text-[13px] shadow-md shadow-app-primary/20 active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              <span className="material-symbols-outlined text-[18px]">calendar_add_on</span>
              Schedule Appointment
            </button>
          </div>
        ))}
      </section>

      {/* Completed Visits Section */}
      <section>
        <div 
          className="flex items-center justify-between px-1 mb-4 cursor-pointer"
          onClick={() => setCompletedExpanded(!completedExpanded)}
        >
          <h2 className="text-[11px] font-bold text-app-text-muted uppercase tracking-widest">Completed Visits</h2>
          <span className={`material-symbols-outlined text-app-text-muted transition-transform ${completedExpanded ? '' : '-rotate-90'}`}>
            expand_more
          </span>
        </div>
        {completedExpanded && (
          <div className="space-y-2 animate-in fade-in duration-300">
            {patient.appointments.completed.map(appt => (
              <div key={appt.id} className="flex items-center justify-between p-4 bg-white rounded-xl border border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center">
                    <span className="material-symbols-outlined text-emerald-600 text-[18px] font-bold">check</span>
                  </div>
                  <div>
                    <p className="text-sm font-bold text-app-text-dark">{appt.title}</p>
                    <p className="text-[10px] text-app-text-muted uppercase font-bold">{appt.date}</p>
                  </div>
                </div>
                <span className="material-symbols-outlined text-slate-200 text-[20px]">info</span>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
