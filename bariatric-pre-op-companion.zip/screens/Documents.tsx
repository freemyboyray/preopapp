
import React, { useRef } from 'react';
import { PatientData } from '../types';

interface DocumentsProps {
  patient: PatientData;
  onUpload: (id: string) => void;
}

export default function Documents({ patient, onUpload }: DocumentsProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const activeDocId = useRef<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      // Find which doc needs uploading if we specifically clicked "Upload Now"
      const docToUpload = activeDocId.current 
        ? patient.documents.find(d => d.id === activeDocId.current) 
        : patient.documents.find(d => d.status === 'not_submitted');
      
      if (docToUpload) {
        onUpload(docToUpload.id);
      } else {
        // Just upload the first one that makes sense
        const first = patient.documents.find(d => d.status === 'not_submitted');
        if (first) onUpload(first.id);
      }
      activeDocId.current = null;
    }
  };

  const triggerUpload = (docId?: string) => {
    activeDocId.current = docId || null;
    fileInputRef.current?.click();
  };

  const uploadHistory = [...patient.documents]
    .filter(d => d.uploadedDate)
    .sort((a, b) => new Date(b.uploadedDate!).getTime() - new Date(a.uploadedDate!).getTime());

  return (
    <div className="px-6 py-8">
      <header className="mb-10">
        <div className="flex items-center gap-4 mb-4">
          <button className="flex h-10 w-10 items-center justify-center rounded-full bg-white shadow-sm border border-slate-50">
            <span className="material-symbols-outlined text-xl">arrow_back</span>
          </button>
          <h1 className="font-serif text-3xl font-bold tracking-tight">Documents</h1>
        </div>
        <p className="text-app-text-muted text-sm font-medium">Upload and track required files</p>
      </header>

      <input 
        type="file" 
        ref={fileInputRef} 
        onChange={handleFileChange} 
        className="hidden" 
        accept="image/*,application/pdf"
      />

      {/* Upload Dropzone Mock */}
      <section className="mb-10">
        <div className="bg-white rounded-3xl border-2 border-dashed border-slate-200 p-8 flex flex-col items-center text-center shadow-sm">
          <div className="mb-5 bg-app-primary/10 p-5 rounded-full">
            <span className="material-symbols-outlined text-app-primary text-4xl">cloud_upload</span>
          </div>
          <h2 className="text-lg font-bold mb-1">Upload a Document</h2>
          <p className="text-[13px] text-app-text-muted mb-8">Accepted formats: PDF, JPG, PNG</p>
          <div className="w-full space-y-3">
            <button 
              onClick={() => triggerUpload()}
              className="w-full h-14 bg-app-primary text-white font-bold rounded-2xl flex items-center justify-center gap-3 hover:bg-app-primary/90 transition-all active:scale-95 shadow-lg shadow-app-primary/20"
            >
              <span className="material-symbols-outlined text-xl">upload_file</span>
              Upload File
            </button>
            <button 
              onClick={() => triggerUpload()}
              className="w-full h-14 bg-white border border-slate-200 text-app-text-dark font-bold rounded-2xl flex items-center justify-center gap-3 hover:bg-slate-50 transition-all active:scale-95 shadow-sm"
            >
              <span className="material-symbols-outlined text-xl">photo_camera</span>
              Take Photo
            </button>
          </div>
        </div>
      </section>

      {/* Required Docs Section */}
      <section className="mb-10">
        <div className="flex items-center justify-between mb-5 px-1">
          <h3 className="text-lg font-bold text-app-text-dark">Required Documents</h3>
          <span className="text-[10px] font-bold text-app-primary uppercase tracking-widest">{patient.documents.length} Items</span>
        </div>
        <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden divide-y divide-slate-50">
          {patient.documents.map(doc => (
            <div key={doc.id} className="p-5">
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-[15px]">{doc.name}</span>
                <span className={`px-3 py-1 rounded-full text-[9px] font-bold uppercase tracking-wider border ${
                  doc.status === 'verified' || doc.status === 'approved' ? 'bg-emerald-50 text-emerald-600 border-emerald-100' :
                  doc.status === 'under_review' ? 'bg-amber-50 text-amber-600 border-amber-100' :
                  'bg-slate-50 text-slate-400 border-slate-200'
                }`}>
                  {doc.status.replace('_', ' ')}
                </span>
              </div>
              {doc.status === 'not_submitted' && (
                <button 
                  onClick={() => triggerUpload(doc.id)}
                  className="text-app-primary text-[13px] font-bold flex items-center gap-1 mt-2"
                >
                  <span className="material-symbols-outlined text-[18px]">add_circle</span>
                  Upload Now
                </button>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Upload History */}
      <section>
        <h3 className="text-lg font-bold text-app-text-dark mb-5 px-1">Upload History</h3>
        <div className="space-y-4 px-1">
          {uploadHistory.length > 0 ? uploadHistory.map(doc => (
            <div key={doc.id} className="flex items-center gap-3">
              <div className={`w-2 h-2 rounded-full ${
                doc.status === 'verified' || doc.status === 'approved' ? 'bg-emerald-500' : 'bg-amber-500'
              }`}></div>
              <p className="text-sm text-app-text-muted">
                <span className="font-bold text-app-text-dark">{doc.uploadedDate}</span> — {doc.name} — {doc.status.replace('_', ' ')}
              </p>
            </div>
          )) : (
            <p className="text-sm text-app-text-muted italic">No documents uploaded yet.</p>
          )}
        </div>
      </section>
    </div>
  );
}
