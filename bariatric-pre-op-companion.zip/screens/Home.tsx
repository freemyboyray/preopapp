
import React from 'react';
import { PatientData, Tab } from '../types';

interface HomeProps {
  patient: PatientData;
  onTabChange: (tab: Tab) => void;
  showToast: (msg: string) => void;
  nextStep: any;
}

export default function Home({ patient, onTabChange, showToast, nextStep }: HomeProps) {
  const completedCount = patient.requirements.filter(r => r.status === 'complete').length;
  const totalCount = patient.requirements.length;
  const progressPercent = Math.round((completedCount / totalCount) * 100);

  const upcomingApptSummary = patient.appointments.upcoming.filter(a => !a.needsScheduling)[0];

  return (
    <div className="px-6 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="font-serif text-4xl mb-2">Hi, {patient.name} 👋</h1>
        <p className="text-app-text-muted font-medium mb-1">{patient.surgeryType} Journey</p>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-400"></div>
          <p className="text-xs text-app-text-muted">
            Care Coordinator: <span className="font-semibold text-app-text-dark">{patient.coordinator.name}</span>
          </p>
        </div>
      </div>

      {/* Overview Tabs (Mocked UI Toggle) */}
      <div className="mb-8 flex gap-3 overflow-x-auto no-scrollbar">
        <button className="px-5 py-2 rounded-full text-sm font-semibold bg-app-text-dark text-white">Overview</button>
        <button className="px-5 py-2 rounded-full text-sm font-semibold bg-[#F2F1ED] text-app-text-muted">Timeline</button>
        <button className="px-5 py-2 rounded-full text-sm font-semibold bg-[#F2F1ED] text-app-text-muted">Care Team</button>
      </div>

      {/* Progress Card */}
      <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm mb-6">
        <h3 className="text-lg font-bold mb-1">Insurance Approval Progress</h3>
        <p className="text-sm text-app-text-muted mb-6">{completedCount} of {totalCount} required milestones completed</p>
        <div className="w-full h-3 bg-slate-100 rounded-full mb-3 overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-app-accent to-orange-400 rounded-full transition-all duration-700"
            style={{ width: `${progressPercent}%` }}
          ></div>
        </div>
        <div className="flex justify-between text-[10px] font-bold text-app-text-muted uppercase tracking-wider">
          <span>Started</span>
          <span>{progressPercent}% Complete</span>
          <span>Ready</span>
        </div>
      </div>

      {/* Next Step Card */}
      <div className="bg-gradient-to-br from-[#FFE8E0] to-[#FFF9F5] p-6 rounded-[2rem] border border-[#FDEEE8] mb-8 relative overflow-hidden group">
        <div className="absolute -top-4 -right-4 w-24 h-24 bg-app-accent/10 rounded-full blur-2xl"></div>
        <h3 className="font-serif text-2xl mb-1 text-app-text-dark">
          {nextStep.type === 'appointment' ? `Schedule ${nextStep.item.title}` : `Upload ${nextStep.item.name || nextStep.item.title}`}
        </h3>
        <p className="text-sm text-app-text-muted mb-6 leading-relaxed max-w-[85%]">
          Required for insurance submission. This is your final {nextStep.type === 'appointment' ? 'clearance step' : 'missing document'}.
        </p>
        <button 
          onClick={() => onTabChange(nextStep.type === 'appointment' ? Tab.Appointments : Tab.Documents)}
          className="w-full bg-white text-app-text-dark font-bold py-4 rounded-2xl shadow-sm active:scale-95 transition-all"
        >
          {nextStep.type === 'appointment' ? 'Schedule Now' : 'Upload Now'}
        </button>
      </div>

      {/* Checklist Summary */}
      <div className="mb-8">
        <div className="flex justify-between items-end mb-4 px-1">
          <h2 className="font-serif text-2xl">Your Current Checklist</h2>
          <button onClick={() => onTabChange(Tab.Requirements)} className="text-sm font-bold text-app-accent">View All</button>
        </div>
        <div className="space-y-3">
          {patient.requirements.slice(0, 3).map(req => (
            <div key={req.id} className="flex items-center gap-4 bg-white p-4 rounded-2xl border border-slate-50 shadow-sm">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${req.status === 'complete' ? 'bg-green-100 text-green-600' : 'border-2 border-slate-100'}`}>
                {req.status === 'complete' && <span className="material-symbols-outlined text-[20px] font-bold">check</span>}
              </div>
              <div>
                <p className="font-bold text-[15px]">{req.title}</p>
                <p className="text-xs text-app-text-muted">
                  {req.status === 'complete' ? `Completed ${req.meta.completedDate || 'Oct 12'}` : req.detail}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Upcoming Appt Summary */}
      {upcomingApptSummary && (
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <span className="material-symbols-outlined text-app-primary">event</span>
            <div>
              <p className="text-xs font-bold text-app-text-muted uppercase">Upcoming Visit</p>
              <p className="font-bold">{upcomingApptSummary.title}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => showToast("Added to calendar")}
              className="flex-1 bg-slate-50 text-app-text-dark font-bold py-3 rounded-xl text-sm"
            >
              Add to Calendar
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
